#!/usr/bin/env python3
"""
One-time setup for createStandalone: asks for an install directory, copies the
program there, then creates its Python venv and installs requirements.txt into it with pip.
Nothing is installed system-wide, so no sudo is needed.

Run from the unzipped folder with: python3 install.py  (on Windows: py install.py)
The install directory can also be given straight away: python3 install.py /home/pi/createStandalone
Running it again updates the program files and recreates the venv.
(Made by standalone_tools.py.)
"""
import argparse
import shutil
import subprocess
import sys
from pathlib import Path

NAME = 'createStandalone'
MAIN = 'standalone_tools.py'            # the program, in the code folder
REQUIREMENTS = 'code/requirements.txt'     # what pip installs into the venv
SYSTEM_SITE_PACKAGES = True   # whether the venv can also use Python packages already installed on the system

IS_WINDOWS = sys.platform == 'win32'

here = Path(__file__).resolve().parent
default_target = Path.home() / NAME
# Copied into the install directory; the venv and launcher are created there.
program_files = ['README.md', 'code', 'requirements.txt']

if IS_WINDOWS:
    launcher_name = 'run.bat'
    launcher_script = ('@echo off\n'
                       f'rem Start {NAME} using its venv (recreate it with install.py).\n'
                       'cd /d "%~dp0"\n'
                       f'venv\\Scripts\\python.exe -u code\\{MAIN} %*\n')
else:
    launcher_name = 'run.sh'
    launcher_script = ('#!/bin/bash\n'
                       f'# Start {NAME} using its venv (recreate it with python3 install.py).\n'
                       'cd "$(dirname "$0")"\n'
                       f'exec venv/bin/python -u code/{MAIN} "$@"\n')


def ask_target() -> Path:
    try:
        answer = input(f"Enter the directory to install {NAME} into [{default_target}]: ").strip()
    except EOFError:
        # No terminal to answer from (e.g. piped input), so take the default.
        answer = ''
    return Path(answer).expanduser().resolve() if answer else default_target


def copy_program(source: Path, target: Path):
    target.mkdir(parents=True, exist_ok=True)
    if target != source:
        print(f"Copying {NAME} into {target}")
        for name in program_files:
            path = source / name
            if path.is_dir():
                shutil.copytree(path, target / name, dirs_exist_ok=True,
                                ignore=shutil.ignore_patterns('__pycache__', '*.pyc', 'venv'))
            elif path.is_file():
                shutil.copy2(path, target / name)
    launcher = target / launcher_name
    launcher.write_text(launcher_script)
    launcher.chmod(0o755)


def create_venv(target: Path):
    # Use the base Python, since sys.executable may be inside the venv being deleted.
    venv = target / 'venv'
    if IS_WINDOWS:
        python = Path(sys.base_prefix) / 'python.exe'
        venv_python = venv / 'Scripts' / 'python.exe'
        venv_options = []
    else:
        python = Path(sys.base_prefix) / 'bin' / 'python3'
        venv_python = venv / 'bin' / 'python'
        venv_options = ['--system-site-packages'] if SYSTEM_SITE_PACKAGES else []
    shutil.rmtree(venv, ignore_errors=True)
    print(f"Creating the venv in {venv}")
    if subprocess.run([str(python), '-m', 'venv', *venv_options, str(venv)]).returncode != 0:
        # Debian / Raspberry Pi OS leave venv's pip out of the base Python package
        sys.exit("Could not create the venv. On Debian or Raspberry Pi OS the venv module needs the python3-venv "
                 "package, which the system administrator installs with: sudo apt install python3-venv")
    # The venv's own pip, so this works where the system Python is "externally managed"
    subprocess.run([str(venv_python), '-m', 'pip', 'install', '-r', str(target / REQUIREMENTS)], check=True)
    print('venv ready')


def main():
    parser = argparse.ArgumentParser(description=f'Install {NAME}')
    parser.add_argument('target', nargs='?', help=f'the directory to install into (asked for when left out)')
    parser.add_argument('--source', help='the folder holding README.md and code (default: the folder this script is in)')
    args = parser.parse_args()
    source = Path(args.source).expanduser().resolve() if args.source else here
    target = Path(args.target).expanduser().resolve() if args.target else ask_target()
    try:
        copy_program(source, target)
        create_venv(target)
    except subprocess.CalledProcessError as e:
        sys.exit(f"Install failed: {' '.join(e.cmd)} exited with {e.returncode}")
    except OSError as e:
        sys.exit(f"Install failed: {e}")
    print()
    print(f"{NAME} is installed in {target}. Start it with: {target / launcher_name}")


if __name__ == '__main__':
    main()
