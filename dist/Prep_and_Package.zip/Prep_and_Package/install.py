#!/usr/bin/env python3
"""
One-time setup for Prep_and_Package: asks for an install directory, copies the
program there, then creates its Python venv and installs requirements.txt into it with pip.
Nothing is installed system-wide, so no sudo is needed.

Run from the unzipped folder with: ./run.sh or python3 install.py  (on Windows: run.bat or py install.py)
The install directory is chosen in a folder window when there is a desktop and Python has tkinter
(otherwise it is asked for in the terminal; --no-gui always asks in the terminal).
It can also be given straight away: python3 install.py /home/pi/Prep_and_Package
Once installed, the program is started with its launcher (run.sh, or run.bat on Windows);
add --no-run to install without starting it.
Running it again updates the program files and recreates the venv.
(Made by prep_and_package.py.)
"""
import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

NAME = 'Prep_and_Package'
MAIN = 'prep_and_package.py'            # the program, in the code folder
REQUIREMENTS = 'code/requirements.txt'     # what pip installs into the venv
SYSTEM_SITE_PACKAGES = True   # whether the venv can also use Python packages already installed on the system

IS_WINDOWS = sys.platform == 'win32'

here = Path(__file__).resolve().parent
default_target = Path.home() / NAME
# Copied into the install directory; the venv and launcher are created there.
program_files = ['README.md', 'code', 'requirements.txt']

if IS_WINDOWS:
    launcher_name = 'run.bat'
    launcher_script = ('@echo off\n'
                       f'rem Start {NAME} using its venv (recreate it with install.py).\n'
                       'cd /d "%~dp0"\n'
                       f'venv\\Scripts\\python.exe -u code\\{MAIN} %*\n')
else:
    launcher_name = 'run.sh'
    launcher_script = ('#!/bin/bash\n'
                       f'# Start {NAME} using its venv (recreate it with python3 install.py).\n'
                       'cd "$(dirname "$0")"\n'
                       f'exec venv/bin/python -u code/{MAIN} "$@"\n')


def gui():
    """A hidden Tk window for showing dialogs, or None when there is no desktop or Python has no tkinter
    (e.g. over SSH, on a Pi without a screen, or Debian without the python3-tk package). Says why when there is none."""
    if not IS_WINDOWS and not (os.environ.get('DISPLAY') or os.environ.get('WAYLAND_DISPLAY')):
        print("No folder window: no desktop here (DISPLAY is not set), so asking in the terminal")
        return None
    try:
        import tkinter
        root = tkinter.Tk()
    except Exception as e:
        print(f"No folder window ({type(e).__name__}: {e}), so asking in the terminal")
        return None
    # A hidden window's "on top" setting does not reach its dialogs on every desktop (they can open behind an
    # editor or the terminal), so show a tiny transparent window, raised and focused, for the dialogs to open over
    root.title(f"Install {NAME}")
    root.geometry('1x1+0+0')
    try:
        root.attributes('-alpha', 0.0)
    except Exception:
        pass
    root.attributes('-topmost', True)
    root.deiconify()
    root.lift()
    root.focus_force()
    root.update()
    return root


def ask_target_gui(root) -> Path:
    """Choose the install directory in a folder window. Returns None if cancelled."""
    from tkinter import filedialog, messagebox
    while True:
        picked = filedialog.askdirectory(
            parent=root, initialdir=str(Path.home()), mustexist=False,
            title=f"Choose where to install {NAME} (a {NAME} folder is made in it), or type a new folder")
        if not picked:
            return None
        picked = Path(picked).expanduser().resolve()
        # A folder typed in that does not exist yet is made and used as it is. Choosing an existing install (a folder
        # called NAME) installs over it; any other existing folder gets a NAME folder made in it
        target = picked if not picked.exists() or picked.name == NAME else picked / NAME
        if target.exists() and not target.is_dir():
            messagebox.showerror(f"Install {NAME}", f"{target} is a file, not a folder.", parent=root)
            continue
        answer = messagebox.askyesnocancel(
            f"Install {NAME}", f"Install {NAME} into\n\n{target}\n\n"
            "Yes to install, No to choose another folder, Cancel to stop.", parent=root)
        if answer is None:
            return None
        if answer:
            return target


def ask_target_text() -> Path:
    try:
        answer = input(f"Enter the directory to install {NAME} into [{default_target}]: ").strip()
    except EOFError:
        # No terminal to answer from (e.g. piped input), so take the default.
        answer = ''
    return Path(answer).expanduser().resolve() if answer else default_target


def show_error(root, text):
    """Report a failed install in a message box too, when the folder was chosen in a window."""
    if root is not None:
        from tkinter import messagebox
        messagebox.showerror(f"Install {NAME}", text, parent=root)


def copy_program(source: Path, target: Path):
    target.mkdir(parents=True, exist_ok=True)
    if target != source:
        print(f"Copying {NAME} into {target}")
        for name in program_files:
            path = source / name
            if path.is_dir():
                shutil.copytree(path, target / name, dirs_exist_ok=True,
                                ignore=shutil.ignore_patterns('__pycache__', '*.pyc', 'venv'))
            elif path.is_file():
                shutil.copy2(path, target / name)
    launcher = target / launcher_name
    launcher.write_text(launcher_script)
    launcher.chmod(0o755)


def create_venv(target: Path):
    # Use the base Python, since sys.executable may be inside the venv being deleted.
    venv = target / 'venv'
    if IS_WINDOWS:
        python = Path(sys.base_prefix) / 'python.exe'
        venv_python = venv / 'Scripts' / 'python.exe'
        venv_options = []
    else:
        python = Path(sys.base_prefix) / 'bin' / 'python3'
        venv_python = venv / 'bin' / 'python'
        venv_options = ['--system-site-packages'] if SYSTEM_SITE_PACKAGES else []
    shutil.rmtree(venv, ignore_errors=True)
    print(f"Creating the venv in {venv}")
    if subprocess.run([str(python), '-m', 'venv', *venv_options, str(venv)]).returncode != 0:
        # Debian / Raspberry Pi OS leave venv's pip out of the base Python package
        sys.exit("Could not create the venv. On Debian or Raspberry Pi OS the venv module needs the python3-venv "
                 "package, which the system administrator installs with: sudo apt install python3-venv")
    # The venv's own pip, so this works where the system Python is "externally managed"
    subprocess.run([str(venv_python), '-m', 'pip', 'install', '-r', str(target / REQUIREMENTS)], check=True)
    print('venv ready')


def main():
    parser = argparse.ArgumentParser(description=f'Install {NAME}')
    parser.add_argument('target', nargs='?', help=f'the directory to install into (asked for when left out)')
    parser.add_argument('--source', help='the folder holding README.md and code (default: the folder this script is in)')
    parser.add_argument('--no-run', action='store_true', help=f'do not start {NAME} once it is installed')
    parser.add_argument('--no-gui', action='store_true', help='ask for the install directory in the terminal, not in a window')
    args = parser.parse_args()
    source = Path(args.source).expanduser().resolve() if args.source else here
    root = None
    if args.target:
        target = Path(args.target).expanduser().resolve()
    else:
        root = None if args.no_gui else gui()
        target = ask_target_gui(root) if root is not None else ask_target_text()
        if target is None:
            sys.exit("Install cancelled")
        print(f"Installing {NAME} into {target}", flush=True)
    try:
        copy_program(source, target)
        create_venv(target)
    except SystemExit as e:   # create_venv's own message (the venv module is missing)
        show_error(root, str(e))
        raise
    except subprocess.CalledProcessError as e:
        message = f"Install failed: {' '.join(e.cmd)} exited with {e.returncode}"
        show_error(root, message + "\n\nThe terminal shows what went wrong.")
        sys.exit(message)
    except OSError as e:
        show_error(root, f"Install failed: {e}")
        sys.exit(f"Install failed: {e}")
    if root is not None:
        root.destroy()
    launcher = target / launcher_name
    print()
    print(f"{NAME} is installed in {target}. Start it with: {launcher}")
    if args.no_run:
        return
    print(f"Starting {NAME} with {launcher}")
    print(flush=True)   # before the program's own output
    try:
        # run.bat needs cmd; run.sh is executable
        code = subprocess.call(['cmd', '/c', str(launcher)] if IS_WINDOWS else [str(launcher)], cwd=str(target))
    except KeyboardInterrupt:   # Ctrl+C stops the program; nothing more to report
        code = 130
    except OSError as e:
        sys.exit(f"Could not start {launcher}: {e}")
    sys.exit(code)


if __name__ == '__main__':
    main()
