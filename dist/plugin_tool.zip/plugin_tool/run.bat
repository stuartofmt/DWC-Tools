@echo off
rem Install the program (made by prep_and_package.py). Arguments go to install.py.
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py -3 install.py %*) else (python install.py %*)
if errorlevel 1 pause
